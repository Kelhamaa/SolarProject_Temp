from fastapi import APIRouter

density=APIRouter()

@density.get("/density")
async def get_density(density: str=None):
    return {"density":density}








