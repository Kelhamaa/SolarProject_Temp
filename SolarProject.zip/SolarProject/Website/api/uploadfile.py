from fastapi import FastAPI, File,APIRouter,UploadFile
import os
uploadfile = APIRouter()



# suitable for small size files
@uploadfile.post("/files/")
async def get_files_len(files: list[bytes]=File()):
    # for small files
    for file in files:
        print(len(file))

    return {"file": [len(file) for file in files]}





# for large size files
@uploadfile.post("/uploadfiles/")
async def create_upload_files(files: list[UploadFile]):
    for file in files:
        path=os.path.join("img",file.filename)
        with open(path,"wb") as f:
            # save files
            for line in file.file:
                f.write(line)


    return {"filenames": [file.filename for file in files]}





