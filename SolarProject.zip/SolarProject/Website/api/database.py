from tortoise import Tortoise
from tortoise import fields
from tortoise.models import Model

class structureindb(Model):
    id = fields.IntField(pk=True)
    formula = fields.CharField(max_length=64, unique=True)
    mean_atomic_numbers=fields.FloatField(description="Mean atomic")
    max_atomic_numbers=fields.FloatField(description="Max atomic")
    min_atomic_numbers=fields.FloatField(description="Min")
    std_atomic_numbers=fields.FloatField(description="std")
    a_parameters=fields.FloatField(description="a_parameters")
    b_parameters=fields.FloatField(description="b_parameters")
    c_parameters=fields.FloatField(description="c_parameters")
    alpha_parameters=fields.FloatField(description="alpha")
    beta_parameters=fields.FloatField(description="beta")
    gamma_parameters=fields.FloatField(description="gamma")
    max_distance=fields.FloatField(description="Max distance")
    min_distance=fields.FloatField(description="Min distance")
    std_distance=fields.FloatField(description="std distance")

class testtable(Model):
    id = fields.IntField(pk=True)
    name=fields.CharField(max_length=64, unique=True)
    mass=fields.FloatField(description="Mass")














