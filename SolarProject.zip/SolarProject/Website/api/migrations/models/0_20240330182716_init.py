from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        CREATE TABLE IF NOT EXISTS `structureindb` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `formula` VARCHAR(64) NOT NULL UNIQUE,
    `mean_atomic_numbers` DOUBLE NOT NULL  COMMENT 'Mean atomic',
    `max_atomic_numbers` DOUBLE NOT NULL  COMMENT 'Max atomic',
    `min_atomic_numbers` DOUBLE NOT NULL  COMMENT 'Min',
    `std_atomic_numbers` DOUBLE NOT NULL  COMMENT 'std',
    `a_parameters` DOUBLE NOT NULL  COMMENT 'a_parameters',
    `b_parameters` DOUBLE NOT NULL  COMMENT 'b_parameters',
    `c_parameters` DOUBLE NOT NULL  COMMENT 'c_parameters',
    `alpha_parameters` DOUBLE NOT NULL  COMMENT 'alpha',
    `beta_parameters` DOUBLE NOT NULL  COMMENT 'beta',
    `gamma_parameters` DOUBLE NOT NULL  COMMENT 'gamma',
    `max_distance` DOUBLE NOT NULL  COMMENT 'Max distance',
    `min_distance` DOUBLE NOT NULL  COMMENT 'Min distance',
    `std_distance` DOUBLE NOT NULL  COMMENT 'std distance'
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `testtable` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(64) NOT NULL UNIQUE
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `aerich` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `version` VARCHAR(255) NOT NULL,
    `app` VARCHAR(100) NOT NULL,
    `content` JSON NOT NULL
) CHARACTER SET utf8mb4;"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        """
