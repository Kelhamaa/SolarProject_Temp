from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        ALTER TABLE `testtable` ADD `mass` DOUBLE NOT NULL  COMMENT 'Mass';"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        ALTER TABLE `testtable` DROP COLUMN `mass`;"""
