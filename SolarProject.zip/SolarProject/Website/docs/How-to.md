---
title: How to use our tool.
sidebar_postion: 3
---
# How to use Solarly

## Overview

Solarly is a web application designed to assist users in validating and predicting solar cell stability and band gap given a hypothetical structure. It provides a user-friendly interface for inputting parameters and retrieving corresponding results.

## Features

- Input form for entering various parameters
- Real-time feedback and output display
- Loading indicator for asynchronous operations
- Easy-to-understand layout and design

## How to Use

### Step 1: Accessing the Application

- Open your web browser and navigate to www.solarly.uk

### Step 2: Inputting Parameters

1. Start by filling in the input fields provided on the main page. Each input field corresponds to a specific parameter required for the calculation.
2. For each parameter, enter the appropriate value as per your requirements. Placeholder values are provided as examples for guidance.
3. Once all required parameters are filled, proceed to the next step.

### Step 3: Submitting the Form

1. After inputting all necessary parameters, click on the "Submit" button located at the bottom of the input form.
2. Upon submission, a loading indicator will appear, indicating that the application is processing your request.

### Step 4: Viewing the Output

1. After a brief processing period, the application will display the output results.
2. The output will include the calculated values based on the input parameters provided.
3. You can review the output displayed in the designated output box.

### Step 5: Further Interaction

- If needed, you can make adjustments to the input parameters and resubmit the form for new calculations.
- The application is designed to be intuitive and user-friendly, allowing for easy interaction and experimentation.

## Troubleshooting

- In case of any issues or errors, please ensure that all input parameters are correctly entered and formatted according to the provided guidelines.
- If the application encounters any errors during processing, it will display appropriate error messages to assist in troubleshooting.

## Support

- For any inquiries or assistance regarding the product, please contact our support team on our Github.

## Feedback

- Your feedback is valuable to us. If you have any suggestions, feature requests, or general feedback, please feel free to share them with us.
- We appreciate your input and strive to continuously improve our product based on user feedback.

