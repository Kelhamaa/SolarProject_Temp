---
title: Project Background & Literature
sidebar_position: 2
---

## Learn About Previous Related Literature

## 1. Accelerated Discovery of Efficient Solar-cell Materials using Quantum and Machine-learning Methods.

### Key Findings
- The research focused on identifying **potential solar cell materials** with high efficiency by combining density functional theory (DFT) high-throughput screening and machine learning techniques¹.
- The study identified **58 potential 2D-bulk solar cell materials** with high potential as thin-film solar-cell materials¹.
- A machine learning **classification model** was trained with the spectroscopy limited maximum efficiency (SLME) data to **predict** whether a material will have an SLME above 10%¹.

### Methodologies
- **Density functional theory (DFT)** high-throughput screening was employed to analyze a large volume of materials data with high accuracy.
- The researchers utilized the **meta-GGA TBmBJ formalism** to obtain frequency-dependent dielectric function data for investigating materials.
- **Effective carrier mass** and **energy above the convex hull** were used to screen candidate materials for **high-efficiency solar applications**.
- **Machine learning techniques** were applied to classify materials based on SLME data and **accelerate** the **discovery of photovoltaic materials**.

### Notable Insights
- The study provides a **comprehensive suite of data, tools, and methodologies** to expedite the **discovery of photovoltaic materials**, potentially impacting the next generation of materials design.
- By leveraging **advanced computational methods and machine learning**, the research offers a promising approach to **identifying efficient solar cell materials** from **crystallographic information and chemical constituents**.
- The integration of **DFT calculations, dielectric function data, and machine learning models** showcases a multidisciplinary approach to materials discovery for renewable energy applications. 

Access the full PDF [here](https://pubs.acs.org/doi/abs/10.1021/acs.chemmater.9b02166)

## 2. Toward Predicting Efficiency of Organic Solar Cells via Machine Learning and Improved Descriptors

### Key Findings
- The research focuses on predicting the efficiency of organic solar cells using machine learning models based on relevant **microscopic properties** of donor/acceptor molecules as descriptors2 .
- The study emphasizes the importance of considering **orbitals energetically** close to frontier orbitals of donor molecules in the energy conversion process of organic photovoltaics2.
- The **dataset of 280 experimental systems** is utilized to reveal correlations between **organic molecule properties and device performance**, leading to the **identification of potential new candidates** for OPVs2.

### Methodologies
- **Quantum chemical calculations** were performed using the Gaussian 09 package to optimize ground state geometries of molecules and calculate various descriptors such as **IP(v), λh, and Ebind**.
- Machine learning techniques accessible from **Scikit-Learn** were employed to build models using a set of descriptors as input to predict PCE.
- Advanced methods like artificial **neural networks, random forest, and gradient boosting regression tree** were utilized to develop **predictive models** for PCE.

### Notable Insights
- The study highlights the need to revisit the **importance of occupied and unoccupied orbitals of organic materials in OPVs**, especially for molecules with **small HOMO-LUMO energy gaps**.
- By leveraging machine learning models, researchers can **quickly screen** and **identify lead candidate materials** for organic solar cells before engaging in laborious synthesis and device fabrication.
- The use of advanced ML techniques like **gradient boosting** has shown promising results in predicting PCE for high-throughput virtual screening of new donor molecules for OPVs.

Access the full PDF [here](https://onlinelibrary.wiley.com/doi/10.1002/aenm.201801032)

## 3. Machine Learning Approach to Delineate the Impact of Material Properties on Solar Cell Device Physics

### Key Findings
- The research focused on understanding the factors influencing solar device efficiency, particularly the **normalized efficiency to power input ratio**.
- The device structure included layers such as an **antireflective coating, glass, FTO electrode, ETL, perovskite layer, HTL, and electrode layer**.
- **Noble metals** like Au, Ag, and Pt were commonly used as electrode materials to **reduce electron-hole recombination**.
- The **perovskite** layer plays a crucial role in **absorbing light** to **create electron-hole pairs** for generating electric current3.
- **TiO2** was utilized as the **ETL**, while **Cu2O** acted as the **HTL** in the investigated solar device structure.

### Methodologies
- **SCAPS** simulation software was employed to study the solar device and investigate the impact of material parameters on efficiency.
- Machine learning algorithms, particularly **random forest models**, were utilized to analyze the dataset and determine the relative importance of input material parameters.
- **Feature Importance and SHAP** analysis were conducted to identify the most influential features affecting the target variable (device efficiency).

### Notable Insights
- Machine learning, as a subfield of artificial intelligence, has become a vital tool in various STEM disciplines, including material science.
- **Perovskite** materials have shown **promising results for light capture** and are crucial for enhancing solar cell performance.
- The study provided insights into how varying material parameters can impact the efficiency of solar devices, aiding experimentalists in optimizing device performance.

Access the full PDF [here](https://pubs.acs.org/doi/10.1021/acsomega.2c01076)

## 4. Exploring optical properties of solar cells by programming and modeling

### Key Findings
- The research explores the optical properties of solar cells, focusing on **reducing reflected light to increase efficiency**.
- The study shows that the **absorption** and **reflection factors** of a solar cell coated with an **anti-reflective layer of SiO2** depend on the **thickness** of the layer and the **wavelength of light**.
- By using the **transfer matrix method**, the authors were able to **determine the optical properties of silicon-based solar cells with different coatings**, such as SiO2 and perovskite Cs17Br174.

### Methodologies
- The research employs the **transfer matrix method** to calculate the **absorption and reflection coefficients** of solar cells with anti-reflective coatings.
- **Programming and modeling techniques** were utilized to analyze the optical properties of solar cells at different thicknesses of SiO2 coatings.
- The study also visualized and graphed the results obtained through Svisual to provide a comprehensive analysis of the defined

### Notable Insights
- The **refractive index of silicon and air** plays a crucial role in the efficiency of solar cells, with the **refractive index of silicon** ranging from **3-4** depending on the wavelength of light.
- Covering the surface of a solar cell with a **100 nm thick SiO2 layer** is recommended to **improve optical properties and increase efficiency**.
- The research suggests that by **enhancing the optical properties** of solar cells, it is possible to **achieve economic success** by reducing costs and increasing efficiency.

Access the full PDF [here](https://gjeta.com/content/exploring-optical-properties-solar-cells-programming-and-modeling)

## 5. The annealing effects of tungsten oxide interlayer based on organic photovoltaic cells

### Key Findings
- The study demonstrated that using a **tungsten oxide interlayer** between **ITO and P3HT:PCBM** in organic photovoltaic cells can significantly **improve** device performance.
- The device with a **40 nm thick WO3 film** annealed at 350°C showed the **highest fill factor** (FF) and **power conversion efficiency (PCE)** among the tested configurations.
- **Annealing the WO3 film** led to **increased hydrophobicity, improved P3HT crystallization, and enhanced hole mobility** in the device.
- The increased work function of the annealed WO3 film **improved hole-collection efficiency by reducing the barrier between P3HT and ITO5**.

### Methodologies
- Surface analysis techniques such as **Atomic Force Microscopy (AFM), X-ray Photoelectron Spectroscopy (XPS), and X-ray Diffraction (XRD)** were used to study the effects of annealing on the WO3 film.
- **Current density-voltage curves and work function variations** were measured to assess hole mobility and interfacial properties.
- **XRD** spectra of P3HT films on WO3 interlayers were analyzed to understand the **structural changes** induced by annealing.

### Notable Insights
- The **annealing process** of the WO3 film resulted in **improved* device performance** by enhancing the properties of the P3HT layer and reducing interfacial barriers.
- The study highlights the **importance of interlayers** in **organic photovoltaic cells** for **efficient charge transport and collection**.
- The findings suggest that **heat-treated** WO3 films can serve as **effective hole collection** materials in **organic photovoltaic devices**.

Access the full PDF [here](https://www.sciencedirect.com/science/article/abs/pii/S0927024813003863?via%3Dihub)
