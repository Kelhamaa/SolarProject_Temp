---
title: Introducing our Materials Project
sidebar_postion: 1
---


# Welcome!

The website aims to serve as a centralized platform for providing access to an AI-powered tool that can predict materials for solar cells which have greater stability, phonon spectra and lesser band gap. The materials are predicted with cutting edge ML algorithms optimised for accuracy to ensure maximal progress in research and industry.

### Goals of this Website:
- Code Storage: To keep and organize the team's code for machine learning models and API development. 
- Material Generation: To use optimized ML models to generate most suited materials for research.
- API Use: Team members and outside partners can use the website to connect to the team's machine learning models. The models take in data and provide information about materials from various online databases. 
- Results Display: sers can see the results of the machine learning models on the website, making it easier to understand and make decisions based on the outcomes.
