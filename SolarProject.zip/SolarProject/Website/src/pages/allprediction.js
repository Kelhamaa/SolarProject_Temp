import React from 'react';

function ShowPredictions({ rf_bandgap, rf_stability }) {
  return (
    <div>
      <h1>Show Predictions</h1>
      <ul>
        <li>RF Bandgap: {rf_bandgap}</li>
        <li>RF Stability: {rf_stability}</li>
      </ul>
    </div>
  );
}

export default ShowPredictions;
