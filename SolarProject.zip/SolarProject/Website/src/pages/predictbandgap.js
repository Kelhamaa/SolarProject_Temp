import React, { useState, useEffect } from 'react';
import axios from 'axios';

function PredictedBandgapPage() {
  const [predictedData, setPredictedData] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Make a GET request to your FastAPI endpoint
      const response = await axios.get('http://localhost:8000/predicted_bandgap');
      // Update component state with the fetched data
      setPredictedData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <h1>Predicted Bandgap</h1>
      {predictedData && (
        <ul>
          <li>Formula: {predictedData.formula}</li>
          <li>Random Forest Bandgap: {predictedData.rf_bandgap}</li>
          <li>XGBoost Bandgap: {predictedData.xgb_bandgap}</li>
          <li>XGBoost Stability: {predictedData.xgb_stability}</li>
        </ul>
      )}
    </div>
  );
}

export default PredictedBandgapPage;
