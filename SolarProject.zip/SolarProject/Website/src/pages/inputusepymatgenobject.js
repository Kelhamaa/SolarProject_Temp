import React, { useState } from 'react';
import axios from 'axios';
import Layout from '@theme/Layout';
import ShowPredictions from './allprediction'; // Import ShowPredictions component
import './product.css'


function AllParametersForm() {
  const [formData, setFormData] = useState({
    element_1: '',
    element_2: '',
    element_3: '',
    abc_str: '',
    angles_str: '',
    volume: '',
    matrix_str: '',
    pbc_str: '',
    frac_coords_1_str: '',
    frac_coords_2_str: '',
    frac_coords_3_str: '',
    frac_coords_4_str: '',
    frac_coords_5_str: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const [predictions, setPredictions] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        const response = await axios.post('http://localhost:8000/allprediction', formData); // Adjust the URL accordingly
        console.log('Response:', response.data);
        // Handle response data if needed
    } catch (error) {
        console.error('Error submitting form:', error);
    }
};
  

  return (
    <Layout>
    <div className='container_for_product'>
      <h1>Solarly</h1>
      <div className='maincontainer'>
      <form onSubmit={handleSubmit} className='productcontainer'>
        <label htmlFor="element_1" className='inputLabel'>Element 1:</label><br />
        <input type="text" id="element_1" name="element_1" value={formData.element_1} onChange={handleChange} className='input' /><br />

        <label htmlFor="element_2" className='inputLabel'>Element 2:</label><br />
        <input type="text" id="element_2" name="element_2" value={formData.element_2} onChange={handleChange} className='input' /><br />

        <label htmlFor="element_3" className='inputLabel'>Element 3:</label><br />
        <input type="text" id="element_3" name="element_3" value={formData.element_3} onChange={handleChange} className='input' /><br />

        <label htmlFor="abc_str" className='inputLabel'>ABC:</label><br />
        <input type="text" id="abc_str" name="abc_str" value={formData.abc_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="angles_str" className='inputLabel'>Angles:</label><br />
        <input type="text" id="angles_str" name="angles_str" value={formData.angles_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="volume" className='inputLabel'>Volume:</label><br />
        <input type="text" id="volume" name="volume" value={formData.volume} onChange={handleChange} className='input' /><br />

        <label htmlFor="matrix_str" className='inputLabel'>Matrix:</label><br />
        <input type="text" id="matrix_str" name="matrix_str" value={formData.matrix_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="pbc_str" className='inputLabel'>PBC:</label><br />
        <input type="text" id="pbc_str" name="pbc_str" value={formData.pbc_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="frac_coords_1_str" className='inputLabel'>Frac Coords 1:</label><br />
        <input type="text" id="frac_coords_1_str" name="frac_coords_1_str" value={formData.frac_coords_1_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="frac_coords_2_str" className='inputLabel'>Frac Coords 2:</label><br />
        <input type="text" id="frac_coords_2_str" name="frac_coords_2_str" value={formData.frac_coords_2_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="frac_coords_3_str" className='inputLabel'>Frac Coords 3:</label><br />
        <input type="text" id="frac_coords_3_str" name="frac_coords_3_str" value={formData.frac_coords_3_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="frac_coords_4_str" className='inputLabel'>Frac Coords 4:</label><br />
        <input type="text" id="frac_coords_4_str" name="frac_coords_4_str" value={formData.frac_coords_4_str} onChange={handleChange} className='input' /><br />

        <label htmlFor="frac_coords_5_str" className='inputLabel'>Frac Coords 5:</label><br />
        <input type="text" id="frac_coords_5_str" name="frac_coords_5_str" value={formData.frac_coords_5_str} onChange={handleChange} className='input' /><br />

        <input type="submit" value="Submit" className="submitButton" />
      </form>
      
      {predictions && <ShowPredictions {...predictions} />} {/* Render predictions if available */}
      </div>
    </div>
    
  </Layout>
  );
}

export default AllParametersForm;

