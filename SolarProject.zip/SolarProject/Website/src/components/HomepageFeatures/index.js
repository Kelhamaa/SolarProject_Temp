import clsx from 'clsx';
import Heading from '@theme/Heading';
import styles from './styles.module.css';

const FeatureList = [
  {
    title: 'Easy to Use',
    Svg: require('@site/static/img/undraw_solution_mindset_re_57bf.svg').default,
    description: (
      <>
        Our straight forward application allows you to easily input data and predict the materials Band Gap!
      </>
    ),
  },
  {
    title: 'Open Source',
    Svg: require('@site/static/img/undraw_undraw_undraw_undraw_team_effort_yj7m_ej3u_wvay_kpbw.svg').default,
    description: (
      <>
        Head over to our Github to reuse our models! Maybe you can even improve them.
      </>
    ),
  },
  {
    title: 'Current',
    Svg: require('@site/static/img/undraw_docusaurus_react.svg').default,
    description: (
      <>
        Trained on the most up to date perovskite data courtesy of The Materials Project.
      </>
    ),
  },
];

function Feature({Svg, title, description}) {
  return (
    <div className={clsx('col col--4')}>
      <div className="text--center">
        <Svg className={styles.featureSvg} role="img" />
      </div>
      <div className="text--center padding-horiz--md">
        <Heading as="h3">{title}</Heading>
        <p>{description}</p>
      </div>
    </div>
  );
}

export default function HomepageFeatures() {
  return (
    <section className={styles.features}>
      <div className="container">
        <div className="row">
          {FeatureList.map((props, idx) => (
            <Feature key={idx} {...props} />
          ))}
        </div>
      </div>
    </section>
  );
}
