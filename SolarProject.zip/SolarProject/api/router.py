from fastapi import APIRouter
from fastapi.openapi.docs import get_swagger_ui_html, get_redoc_html
from fastapi.openapi.models import OpenAPI

router = APIRouter()

@router.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url="/openapi.json",
        title="API Docs",
        oauth2_redirect_url="/docs/oauth2-redirect"
    )

@router.get("/redoc", include_in_schema=False)
async def redoc_html():
    return get_redoc_html(
        openapi_url="/openapi.json",
        title="API Docs",
        oauth2_redirect_url="/docs/oauth2-redirect"
    )


async def get_openapi():
    return {
        "openapi": "3.0.0",
        "info": {
            "title": "Your API",
            "version": "1.0",
            "description": "This is a very nice API",
        },
        "paths": {},
    }



