## retrieve data from material project
from mp_api.client import MPRester
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error,r2_score
import matplotlib.pyplot as plt

key = "Z7NcMZxFm5LyvsQZk9k7sD8ZgMdQZstr"

with MPRester(key) as mpr:
    data = mpr.materials.summary.search(formula='ABC3',
                                        fields=["density", "structure", "material_id", "nelements", "formula_pretty",
                                                "formula_anonymous", "theoretical", "is_stable", "volume", "elements",
                                                "band_gap", "formation_energy"])


mean_atomic_numbers=[]
max_atomic_numbers=[]
min_atomic_numbers=[]
std_atomic_numbers=[]
# position of the atomic
a_parameters=[]
b_parameters=[]
c_parameters=[]
# angles between the bond
alpha_parameters=[]
beta_parameters=[]
gamma_parameters=[]
# distance betweeen atomics
mean_distance_matrix=[]
max_distance_matrix=[]
min_distance_matrix=[]
std_distance_matrix=[]
density=[]
volume=[]
formula=[]

stability=[]


for sam in data:
    sample=sam.structure
    mean_atomic_numbers+=[np.mean(sample.atomic_numbers)]
    max_atomic_numbers+=[np.max(sample.atomic_numbers)]
    min_atomic_numbers+=[np.min(sample.atomic_numbers)]
    std_atomic_numbers+=[np.std(sample.atomic_numbers)]
    a_parameters+=[sample.lattice.abc[0]]
    b_parameters+=[sample.lattice.abc[1]]
    c_parameters+=[sample.lattice.abc[2]]
    alpha_parameters+=[sample.lattice.angles[0]]
    beta_parameters+=[sample.lattice.angles[1]]
    gamma_parameters+=[sample.lattice.angles[2]]
    mean_distance_matrix+=[np.mean(sample.distance_matrix)]
    max_distance_matrix+=[np.max(sample.distance_matrix)]
    min_distance_matrix+=[np.min(sample.distance_matrix)]
    std_distance_matrix+=[np.std(sample.distance_matrix)]

    stability+=[sam.is_stable]

    #formula+=[sam.formula_pretty]

dataset_df= pd.DataFrame({
                        #"formula":formula,
                        "mean_atomic_numbers":mean_atomic_numbers, #
                        "max_atomic_numbers":max_atomic_numbers,
                         "min_atomic_numbers":min_atomic_numbers,
                         "std_atomic_numbers":std_atomic_numbers,
                         "a_parameters":a_parameters,
                         "b_parameters":b_parameters,
                         "c_parameters":c_parameters,
                         "alpha_parameters":alpha_parameters,
                         "beta_parameters":beta_parameters,
                         "gamma_parameters":gamma_parameters,
                         "max_distance_matrix":max_distance_matrix,
                         "min_distance_matrix":min_distance_matrix,
                         "std_distance_matrix":std_distance_matrix,
                         "stable": stability


})


dataset_df["stable"] = dataset_df["stable"].astype(int)
y=dataset_df["stable"].values
X = dataset_df.drop(["stable"], axis=1)

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)


import xgboost as xgb
xgb_model_sta = xgb.XGBClassifier(objective="binary:logistic", random_state=42)
xgb_model_sta.fit(X_train,y_train)
y_pred=xgb_model_sta.predict(X_test)
testing_accuracy = xgb_model_sta.score(X_test, y_test) * 100
print(f' Accuracy on test data: {testing_accuracy:.1f} %')

def xgb_predict_sta(structure):
    structure_df = pd.DataFrame({"mean_atomic_numbers": structure[0],
                                 "max_atomic_numbers": structure[1],
                                 "min_atomic_numbers": structure[2],
                                 "std_atomic_numbers": structure[3],
                                 "a_parameters": structure[4],
                                 "b_parameters": structure[5],
                                 "c_parameters": structure[6],
                                 "alpha_parameters": structure[7],
                                 "beta_parameters": structure[8],
                                 "gamma_parameters": structure[9],
                                 "max_distance_matrix": structure[10],
                                 "min_distance_matrix": structure[11],
                                 "std_distance_matrix": structure[12]
                                 })
    stability_pred = xgb_model_sta.predict(structure_df)
    return stability_pred






