from mp_api.client import MPRester
from multiprocessing import freeze_support

key = "Z7NcMZxFm5LyvsQZk9k7sD8ZgMdQZstr"

with MPRester(key) as mpr:
    data = mpr.materials.summary.search(formula='ABC3',
                                        fields=["structure", "material_id", "nelements", "formula_pretty",
                                                "formula_anonymous", "theoretical", "is_stable", "volume", "elements",
                                                "band_gap", "formation_energy"])



from matminer.featurizers.bandstructure import BranchPointEnergy
from matminer.featurizers.bandstructure import BandFeaturizer
from matminer.featurizers.structure import XRDPowderPattern
from matminer.featurizers.conversions import StrToComposition

import pandas as pd



stable = []
structures = []
band_gaps = []
theory = []
ids = []
formula=[]
for sample in data:
    stable.append(sample.is_stable)
    structures.append(sample.structure)
    band_gaps.append(sample.band_gap)
    theory.append(sample.theoretical)
    ids.append(sample.material_id)
    formula.append(sample.formula_pretty)

perov_df = pd.DataFrame(
    {"material ids": ids,
     "structure": structures,
     "band gaps": band_gaps,
     "theoretical": theory,
     "stable": stable,
     "formula":formula
    })

real_perovs = perov_df[perov_df["theoretical"]==False]
real_perovs["stable"] = real_perovs["stable"].astype(int)

#formula_df = StrToComposition().featurize_dataframe(real_perovs, "formula")
if __name__ == '__main__':
    freeze_support()
    formula_df = StrToComposition().featurize_dataframe(real_perovs, "formula")

from matminer.featurizers.composition import ElementFraction
ef=ElementFraction()
formula_df['element_fraction']=formula_df['composition'].apply(ef.featurize)
import numpy as np
formula_df=formula_df[formula_df["band gaps"]>1]
y = formula_df["band gaps"]
X = np.array(formula_df['element_fraction'])


X_=[]
for i in range(len(X)):
    array=np.array(X[i])
    X_.append(array)
X=pd.DataFrame(X_)

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)

##Randomforest
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import RandomizedSearchCV
rf=RandomForestRegressor()

grid_param={'n_estimators':[int(x) for x in np.linspace(start=100,stop=1000,num=3)],
           'max_features':['auto','sqrt'],
           'max_depth':[int(x) for x in np.linspace(start=10,stop=100,num=3)],
            'min_samples_split':[2,5],
            'min_samples_leaf':[1,2],
            'bootstrap':[True]
           }

rand_ser = RandomizedSearchCV(estimator=rf,param_distributions=grid_param,n_iter=10,)
rand_ser.fit(X_train,y_train)
rf_model=rand_ser.best_estimator_

y_pred=rf_model.predict(X_test)
testing_accuracy = rf_model.score(X_test, y_test) * 100
print(f' Accuracy on test data (rf_model): {testing_accuracy:.1f} %')

## XGBOOST
from xgboost import XGBRegressor
xgb_model = XGBRegressor()

xgb_model.fit(X_train,y_train)
y_pred=xgb_model.predict(X_test)
testing_accuracy = xgb_model.score(X_test, y_test) * 100
print(f' Accuracy on test data (xgb_model): {testing_accuracy:.1f} %')







