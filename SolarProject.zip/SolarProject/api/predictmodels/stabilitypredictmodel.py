
import numpy as np
import pandas as pd
from mp_api.client import MPRester
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from matminer.featurizers.structure import DensityFeatures
from matminer.featurizers.structure import StructuralComplexity
from matminer.featurizers.structure import MaximumPackingEfficiency

with MPRester("EclqWMXn0DY3CAOSELD3xvCjEVhlcEYp") as mpr:
    perovskites = mpr.summary.search(formula=["ABC3"],
                                     fields = ["material_id", "structure", "band_gap", "theoretical", "is_stable", "formula_pretty", "composition"])

def sta_prediction(data,label):
    ids = []
    structures = []
    band_gaps = []
    theory = []
    stable = []
    formula = []
    composition = []

    for i in range(len(data)):
        single = data[i]
        ids.append(single.material_id)
        structures.append(single.structure)
        band_gaps.append(single.band_gap)
        theory.append(single.theoretical)
        stable.append(single.is_stable)
        formula.append(single.formula_pretty)
        composition.append(single.composition)

    perov_df = pd.DataFrame(
        {"material ids": ids,
         "formula": formula,
         "composition": composition,
         "structure": structures,
         "band gaps": band_gaps,
         "theoretical": theory,
         "stable": stable
         })

    real_perovs = perov_df[perov_df["theoretical"] == False]
    real_perovs["stable"] = real_perovs["stable"].astype(int)
    perovs_feat = real_perovs
    ##
    densityf = DensityFeatures()
    strcomp = StructuralComplexity()
    mpe = MaximumPackingEfficiency()

    perovs_feat = densityf.featurize_dataframe(perovs_feat, "structure")
    perovs_feat = strcomp.featurize_dataframe(perovs_feat, "structure")
    perovs_feat = mpe.featurize_dataframe(perovs_feat, "structure")

    y = perovs_feat["stable"].values
    X = perovs_feat.drop(["material ids", "formula", "composition", "structure", "band gaps", "theoretical", "stable"],
                         axis=1)

    X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=0)

    stable_classifier = RandomForestClassifier(random_state=0)
    stable_classifier.fit(X_train, y_train)
    y_pred = stable_classifier.predict(X_test)

    training_accuracy = stable_classifier.score(X_train, y_train) * 100
    print(f'Accuracy on training data: {training_accuracy:.1f} %')
    testing_accuracy = stable_classifier.score(X_test, y_test) * 100
    print(f'Accuracy on {label} testing data: {testing_accuracy:.1f} %')

    return y_pred,testing_accuracy

sta_prediction(perovskites,'perovskites')


with MPRester("EclqWMXn0DY3CAOSELD3xvCjEVhlcEYp") as mpr:
    iii_v = mpr.summary.search(chemsys=["Al-N", "Al-P", "Al-As", "Al-Sb",
                                      "Ga-N", "Ga-P", "Ga-As", "Ga-Sb"
                                      "In-N", "In-P", "In-As", "In-Sb"],
                              fields = ["material_id", "structure", "band_gap", "theoretical", "is_stable", "formula_pretty", "composition"])



######
with MPRester("EclqWMXn0DY3CAOSELD3xvCjEVhlcEYp") as mpr:
    ii_vi = mpr.summary.search(chemsys=["Zn-S", "Zn-Se", "Zn-Te",
                                        "Cd-S", "Cd-Se", "Cd-Te"],
                               fields = ["material_id", "structure", "band_gap", "theoretical", "is_stable", "formula_pretty", "composition"])



y_pred_iii_v,testing_accuracy_iii_v=sta_prediction(iii_v,'iii_v')

y_pred_ii_vi,testing_accuracy_ii_vi=sta_prediction(ii_vi,'ii_vi')
print(f'Accuracy on iii_v testing data: {testing_accuracy_iii_v:.1f} %')
print(f'Accuracy on ii_vi testing data: {testing_accuracy_ii_vi:.1f} %')


