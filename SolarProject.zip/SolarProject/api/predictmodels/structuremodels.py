## retrieve data from material project
from mp_api.client import MPRester
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error,r2_score
import matplotlib.pyplot as plt

key = "Z7NcMZxFm5LyvsQZk9k7sD8ZgMdQZstr"

with MPRester(key) as mpr:
    data = mpr.materials.summary.search(formula='ABC3',
                                        fields=["density", "structure", "material_id", "nelements", "formula_pretty",
                                                "formula_anonymous", "theoretical", "is_stable", "volume", "elements",
                                                "band_gap", "formation_energy"])
mean_atomic_numbers=[]
max_atomic_numbers=[]
min_atomic_numbers=[]
std_atomic_numbers=[]
# position of the atomic
a_parameters=[]
b_parameters=[]
c_parameters=[]
# angles between the bond
alpha_parameters=[]
beta_parameters=[]
gamma_parameters=[]
# distance betweeen atomics
mean_distance_matrix=[]
max_distance_matrix=[]
min_distance_matrix=[]
std_distance_matrix=[]
density=[]
volume=[]
formula=[]

bandgap=[]

for sam in data:
    sample=sam.structure
    if sam.band_gap>1:
        mean_atomic_numbers+=[np.mean(sample.atomic_numbers)]
        max_atomic_numbers+=[np.max(sample.atomic_numbers)]
        min_atomic_numbers+=[np.min(sample.atomic_numbers)]
        std_atomic_numbers+=[np.std(sample.atomic_numbers)]
        a_parameters+=[sample.lattice.abc[0]]
        b_parameters+=[sample.lattice.abc[1]]
        c_parameters+=[sample.lattice.abc[2]]
        alpha_parameters+=[sample.lattice.angles[0]]
        beta_parameters+=[sample.lattice.angles[1]]
        gamma_parameters+=[sample.lattice.angles[2]]
        mean_distance_matrix+=[np.mean(sample.distance_matrix)]
        max_distance_matrix+=[np.max(sample.distance_matrix)]
        min_distance_matrix+=[np.min(sample.distance_matrix)]
        std_distance_matrix+=[np.std(sample.distance_matrix)]

        bandgap+=[sam.band_gap]
        #formula+=[sam.formula_pretty]

dataset_df= pd.DataFrame({
                        #"formula":formula,
                        "mean_atomic_numbers":mean_atomic_numbers, #
                        "max_atomic_numbers":max_atomic_numbers,
                         "min_atomic_numbers":min_atomic_numbers,
                         "std_atomic_numbers":std_atomic_numbers,
                         "a_parameters":a_parameters,
                         "b_parameters":b_parameters,
                         "c_parameters":c_parameters,
                         "alpha_parameters":alpha_parameters,
                         "beta_parameters":beta_parameters,
                         "gamma_parameters":gamma_parameters,
                         "max_distance_matrix":max_distance_matrix,
                         "min_distance_matrix":min_distance_matrix,
                         "std_distance_matrix":std_distance_matrix
                         })

## split the data set
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(dataset_df,bandgap,test_size=0.2,random_state=42)

##Random Forest
from sklearn.ensemble import RandomForestRegressor
rf_model= RandomForestRegressor(n_estimators=1000,max_depth=1000,random_state=42)
rf_model.fit(X_train,y_train)
y_pred=rf_model.predict(X_test)
rf_model_mse=mean_squared_error(y_test,y_pred)
rf_model_r2=r2_score(y_test,y_pred)
training_accuracy = rf_model.score(X_train, y_train) * 100
print(f' Accuracy on train data: {training_accuracy:.1f} %')

testing_accuracy = rf_model.score(X_test, y_test) * 100
print(f' Accuracy on test data: {testing_accuracy:.1f} %')

## XGBoost
from xgboost import XGBRegressor

xgb_model = XGBRegressor()
xgb_model.fit(X_train,y_train)
y_pred=xgb_model.predict(X_test)
xgb_model_mse=mean_squared_error(y_test,y_pred)
xgb_model_r2=r2_score(y_test,y_pred)
training_accuracy = xgb_model.score(X_train, y_train) * 100
print(f' Accuracy on train data: {training_accuracy:.1f} %')
testing_accuracy = xgb_model.score(X_test, y_test) * 100
print(f' Accuracy on test data: {testing_accuracy:.1f} %')
def rf_predict(structure):
    """
    This function is used to predict the bandgap using random forest regressor
    :param structure: the input structure information from client
    :return bandgap_predict: the predicted bandgap values
    """
    structure_df=pd.DataFrame({"mean_atomic_numbers":structure[0],
                          "max_atomic_numbers":structure[1],
                         "min_atomic_numbers":structure[2],
                         "std_atomic_numbers":structure[3],
                         "a_parameters":structure[4],
                         "b_parameters":structure[5],
                         "c_parameters":structure[6],
                         "alpha_parameters":structure[7],
                         "beta_parameters":structure[8],
                         "gamma_parameters":structure[9],
                         "max_distance_matrix":structure[10],
                         "min_distance_matrix":structure[11],
                         "std_distance_matrix":structure[12]
                         })
    print(structure_df)
    bandgap_predict=rf_model.predict(structure_df)

    return bandgap_predict

def xgb_predict_bg(structure):
    """
    This function is used to predict the bandgap using xgboost regressor
    :param structure: the input structure information from client
    :return bandgap_predict: the predicted bandgap values
    """
    structure_df=pd.DataFrame({"mean_atomic_numbers":structure[0],
                          "max_atomic_numbers":structure[1],
                         "min_atomic_numbers":structure[2],
                         "std_atomic_numbers":structure[3],
                         "a_parameters":structure[4],
                         "b_parameters":structure[5],
                         "c_parameters":structure[6],
                         "alpha_parameters":structure[7],
                         "beta_parameters":structure[8],
                         "gamma_parameters":structure[9],
                         "max_distance_matrix":structure[10],
                         "min_distance_matrix":structure[11],
                         "std_distance_matrix":structure[12]
                         })
    bandgap_predict=xgb_model.predict(structure_df)
    return bandgap_predict


print('done')
