# This readme file is used to show how to use this API.

1: Create a new environment and install all the dependencies in the groupprojectenv.yaml file.
--Open an Anaconda prompt window, cd to the folder with yaml file in it.
--Run the following command line to install

`conda env create -f groupprojectenv.yaml`

2: Initiate the tables in database.( Open the terminal and run these command line)

`aerich init -t setting.TORTOISE_ORM`  # If there is the 'migrations' folder already, delete it and run this line.

`aerich init -db`

`aerich migration`  # If you changed any class in database.py file, run this line to generate the migrations file again. Otherwise do not run this line and the following two lines.

`aerich upgrade`  # upgrade any change above.

`aerich downgrade` # downgrade the change.

`aerich history`  # this command line is used to see the migration records.

3: Run the main.py in the created environment above.

Now the API with the machine learning models is working. 

4: Go to a browser to interact with models through api.

https://127.0.0.1:8080/getpymatgenobject    # input compound information and see the prediction values.

https://127.0.0.1:8080/allobjectsindb       # all predicted compounds can be seen in this page. 

5: This interface takes structure information as input.

https://127.0.0.1:8080/predictbandgap  # input structure information and see the prediction values.



