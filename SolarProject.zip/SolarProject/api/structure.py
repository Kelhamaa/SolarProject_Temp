from fastapi import APIRouter, Request, HTTPException, Form
import uvicorn
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, validator
from predictmodels.structuremodels import rf_predict,xgb_predict_bg
from predictmodels.structurestabilitymodel import xgb_predict_sta
import pandas as pd
import numpy as np

from database import *

struc = APIRouter()


class StructureIn(BaseModel):
    #id = fields.IntField(pk=True)
    formula: str
    mean_atomic_numbers : float
    max_atomic_numbers : float
    min_atomic_numbers : float
    std_atomic_numbers : float
    a_parameters  : float
    b_parameters : float
    c_parameters : float
    alpha_parameters : float
    beta_parameters : float
    gamma_parameters : float
    max_distance : float
    min_distance : float
    std_distance : float

    @validator('formula') # validate whether the formula is empty
    def formula_validation(cls, formula):
        assert formula, "formula cannot be empty"
        return formula


template = Jinja2Templates(directory="template")

# return information of all
@struc.get("/structure")
async def get_all_structure(request:Request):
    try:
        structures = await structureindb.all()
        if not structures:
            return "No structures found"

        return template.TemplateResponse(
            "index.html",
            {
                "request": request,
                "structures": structures
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# return information of specific formula
@struc.get("/structure/{formula}")
async def get_specific_structure(formula:str,request:Request):
    try:
        structures = await structureindb.filter(formula=formula)
        if not structures:
            return "No structures found"

        return template.TemplateResponse(
            "index.html",
            {
                "request": request,
                "structures": structures
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
@struc.get("/getstructureinfo")
async def get_structure_info(request: Request):

    return template.TemplateResponse(
        "structure.html",
        {
            "request": request
        }
    )
# add new structure information
@struc.post("/predictbandgap")
async def post_structure(request: Request,formula: str = Form(), mean_atomic_numbers: float = Form(),
                         max_atomic_numbers: float = Form(), min_atomic_numbers: float = Form(),
                         std_atomic_numbers: float = Form(), a_parameters: float = Form(),
                         b_parameters: float = Form(), c_parameters: float = Form(),
                         alpha_parameters: float = Form(), beta_parameters: float = Form(),
                         gamma_parameters: float = Form(), max_distance: float = Form(),
                         min_distance: float = Form(), std_distance: float = Form()
                         ):
    print(formula)
    print(mean_atomic_numbers)
    structure = await structureindb.create(formula=formula,
                                          mean_atomic_numbers=mean_atomic_numbers,
                                          max_atomic_numbers = max_atomic_numbers,
                                          min_atomic_numbers =min_atomic_numbers,
                                          std_atomic_numbers =std_atomic_numbers,
                                          a_parameters =a_parameters,
                                          b_parameters =b_parameters,
                                          c_parameters =c_parameters,
                                          alpha_parameters =alpha_parameters,
                                          beta_parameters =beta_parameters,
                                          gamma_parameters =gamma_parameters,
                                          max_distance =max_distance,
                                          min_distance =min_distance,
                                          std_distance =std_distance
                                        )
    structure_info = [[mean_atomic_numbers],
                      [max_atomic_numbers],
                      [min_atomic_numbers],
                      [std_atomic_numbers],
                      [a_parameters],
                      [b_parameters],
                      [c_parameters],
                      [alpha_parameters],
                      [beta_parameters],
                      [gamma_parameters],
                      [max_distance],
                      [min_distance],
                      [std_distance]]
    print(structure_info)
    print(type(structure_info))
    rf_bandgap = rf_predict(structure_info)
    xgb_bandgap = xgb_predict_bg(structure_info)
    xgb_stability = xgb_predict_sta(structure_info)
    return template.TemplateResponse(
        "predictbandgap.html",
        {
            "request": request,
            "formula": formula,
            "rf_bandgap": rf_bandgap.tolist(),  ## fastapi doesn't support serialization of NumPy arrays directly. Convert into list before return it.
            "xgb_bandgap": xgb_bandgap.tolist(),
            "xgb_stability": xgb_stability.tolist()
        }
    )
# update information according to formula
@struc.put("/structure/{formula}")
async def update_structure(formula: str, structure_in: StructureIn):
    data=structure_in.dict()
    await structureindb.filter(formula=formula).update(**data)
    edit_structure = await structureindb.filter(formula=formula)
    return edit_structure

# delete record according to formula
@struc.delete("/structure/{formula}")
async def delete_structure(formula: str):
    deletecount = await structureindb.filter(formula=formula).delete()
    if not deletecount:
        raise HTTPException(status_code=404, detail=f"formula:{formula} not found")

    return {}



