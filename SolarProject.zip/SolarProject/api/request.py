from fastapi import APIRouter, Request
req=APIRouter()

@req.post("/request")
async def get_request_info(request: Request):
    print("url",request.url)
    print("client IP address", request.client.host)
    print("client port", request.client.port)
    print("header", request.headers.get("user-agent"))
    return {
        "url": request.url,
        "client IP address":request.client.host,
        "client port":request.client.port,
        "header": request.headers.get("user-agent")
    }
