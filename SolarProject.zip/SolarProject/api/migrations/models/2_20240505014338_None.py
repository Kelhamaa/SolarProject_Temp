from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        CREATE TABLE IF NOT EXISTS `pymatgenobjectindb` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `element1` VARCHAR(2) NOT NULL  COMMENT 'element 1',
    `element2` VARCHAR(2) NOT NULL  COMMENT 'element 2',
    `element3` VARCHAR(2) NOT NULL  COMMENT 'element 3',
    `abc` VARCHAR(100) NOT NULL  COMMENT 'abc',
    `angles` VARCHAR(100) NOT NULL  COMMENT 'angles',
    `volume` VARCHAR(100) NOT NULL  COMMENT 'volume',
    `matrix` VARCHAR(100) NOT NULL  COMMENT 'matrix',
    `pbc` VARCHAR(100) NOT NULL  COMMENT 'pbc',
    `frac_coords_1` VARCHAR(100) NOT NULL  COMMENT 'frac_coords_1',
    `frac_coords_2` VARCHAR(100) NOT NULL  COMMENT 'frac_coords_2',
    `frac_coords_3` VARCHAR(100) NOT NULL  COMMENT 'frac_coords_3',
    `frac_coords_4` VARCHAR(100) NOT NULL  COMMENT 'frac_coords_4',
    `frac_coords_5` VARCHAR(100) NOT NULL  COMMENT 'frac_coords_5',
    `stability` VARCHAR(10) NOT NULL  COMMENT 'stability',
    `bandgap` DOUBLE NOT NULL  COMMENT 'bandgap'
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `structureindb` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `formula` VARCHAR(64) NOT NULL UNIQUE,
    `mean_atomic_numbers` DOUBLE NOT NULL  COMMENT 'Mean atomic',
    `max_atomic_numbers` DOUBLE NOT NULL  COMMENT 'Max atomic',
    `min_atomic_numbers` DOUBLE NOT NULL  COMMENT 'Min',
    `std_atomic_numbers` DOUBLE NOT NULL  COMMENT 'std',
    `a_parameters` DOUBLE NOT NULL  COMMENT 'a_parameters',
    `b_parameters` DOUBLE NOT NULL  COMMENT 'b_parameters',
    `c_parameters` DOUBLE NOT NULL  COMMENT 'c_parameters',
    `alpha_parameters` DOUBLE NOT NULL  COMMENT 'alpha',
    `beta_parameters` DOUBLE NOT NULL  COMMENT 'beta',
    `gamma_parameters` DOUBLE NOT NULL  COMMENT 'gamma',
    `max_distance` DOUBLE NOT NULL  COMMENT 'Max distance',
    `min_distance` DOUBLE NOT NULL  COMMENT 'Min distance',
    `std_distance` DOUBLE NOT NULL  COMMENT 'std distance'
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `testtable` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(64) NOT NULL UNIQUE,
    `mass` DOUBLE NOT NULL  COMMENT 'Mass'
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `aerich` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `version` VARCHAR(255) NOT NULL,
    `app` VARCHAR(100) NOT NULL,
    `content` JSON NOT NULL
) CHARACTER SET utf8mb4;"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        """
