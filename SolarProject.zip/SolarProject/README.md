### Welcome to our solar cell project!

## How to run:

In order to run our project you will most likely need to install some additional software.

# Here is a list of the softwares and packages we used:
- node.js
- Uvicorn
- All the dependecies in the node_modules folder, these can be automatically installed by running ```npm install ```.

# To start the api:
- run ```uvicorn main:app --reload``` when in the /api folder.
- Once you receive the message: ```Application startup complete.``` this means the API has started succesfully.

# To start website:
- Navigate to the /Website folder.
- Run command ```npm start```
- This will start the react app on your localhost.

# Troubleshooting:
- Over the course of this project there has been some issues with the frontend communicating to the API depending on the laptop being used and other various reasons.
- If you encounter any issues using the frontend tool we have a locally hosted alternative in the /api folder.

# How to use alternative api:
- Whilst the api is started
- Open the inputusepymatgenobject.html file in your browser.
- Input object features.
- Get results.
