#importing packages
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from pymatgen.core import Structure, Composition
from matminer.featurizers.structure import DensityFeatures, StructuralComplexity, MaximumPackingEfficiency
from matminer.featurizers.composition import ElementProperty
from matminer.featurizers.conversions import CompositionToOxidComposition
from matminer.featurizers.composition.ion import ElectronegativityDiff
from matminer.featurizers.structure.matrix import OrbitalFieldMatrix

#training stability model
stablility_data = pd.read_csv("stability_data.csv")
y = stablility_data["stable"].values
X = stablility_data.drop("stable", axis=1)
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=0)
stability_classifier = RandomForestClassifier(random_state=0)
stability_classifier.fit(X_train, y_train)

#training bandgap model
bandgap_data = pd.read_csv("bandgap_data.csv")
y = bandgap_data["band gaps"].values
X = bandgap_data.drop("band gaps", axis=1)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
bandgap_regressor = RandomForestRegressor(random_state=0)
bandgap_regressor.fit(X_train, y_train)

#making a function to turn inputs into pymatgen objects
def pymatgen_converter(element_1, element_2, element_3, abc, angles, volume, matrix, pbc, frac_coords_1, frac_coords_2, frac_coords_3, frac_coords_4, frac_coords_5):
    """
    Taking inputs and making a pymatgen composition object and structure object.
    Args:
        element_1      (string)
        element_2      (string)
        element_3      (string)
        abc            (array of floats)
        angles         (array of floats)
        volume         (float)
        matrix         (array of arrays of floats)
        pbc            (array of Booleans - always True I think)
        frac_coords_1  (list of floats)
        frac_coords_2  (list of floats)
        frac_coords_3  (list of floats)
        frac_coords_4  (list of floats)
        frac_coords_5  (list of floats)
    Returns:
        composition (pymatgen composition)
        structure (pymatgen structure)
    """
    composition_dict = {element_1: 1, element_2: 1, element_3: 3}
    composition = Composition(composition_dict)
    
    structure_dict = {
        "lattice": {
            "abc": abc,
            "angles": angles,
            "volume": volume,
            "matrix": matrix,
            "pbc": pbc
        },
        "sites": [
            {"species": [{"element": element_1, "occu": 1}], "abc": frac_coords_1},
            {"species": [{"element": element_2, "occu": 1}], "abc": frac_coords_2},
            {"species": [{"element": element_3, "occu": 1}], "abc": frac_coords_3},
            {"species": [{"element": element_3, "occu": 1}], "abc": frac_coords_4},
            {"species": [{"element": element_3, "occu": 1}], "abc": frac_coords_5}
        ]
    }
    structure = Structure.from_dict(structure_dict)

    return composition, structure


#making an example material
material = pymatgen_converter("Ac", "Al", "O", 
                   [3.85863387, 3.85863387, 3.85863387], 
                   [90.0, 90.0, 90.0], 
                   57.4514132376898, 
                   [[3.85863387, -0.0, 0.0], [-0.0, 3.85863387, 0.0], [-0.0, -0.0, 3.85863387]], 
                   [True, True, True], 
                   (0.0, 0.0, 0.0), (0.5, 0.5, 0.5), (0.5, 0.5, 0.0), (0.5, 0.0, 0.5), (0.0, 0.5, 0.5))


#generating features from example material to be used in models

#stability model example
df_feats = DensityFeatures().featurize(material[1])
sc_feats = StructuralComplexity().featurize(material[1])
mpe_feats = MaximumPackingEfficiency().featurize(material[1])

stability_feats = []
for i in df_feats:
    stability_feats.append(i)
for i in sc_feats:
    stability_feats.append(i)
for i in mpe_feats:
    stability_feats.append(i)

df_labels = DensityFeatures().feature_labels()
sc_labels = StructuralComplexity().feature_labels()
mpe_labels = MaximumPackingEfficiency().feature_labels()

stability_labels = []
for i in df_labels:
    stability_labels.append(i)
for i in sc_labels:
    stability_labels.append(i)
for i in mpe_labels:
    stability_labels.append(i)

stability_feats_df = pd.DataFrame(stability_feats).T
stability_feats_df.columns = stability_labels

print(f"Stable: {stability_classifier.predict(stability_feats_df)[0]}")

#bandgap model example
ep_feat = ElementProperty.from_preset(preset_name="magpie")
ep_feats = ep_feat.featurize(material[0])
ctoc_feats = CompositionToOxidComposition().featurize(material[0])
en_feats = ElectronegativityDiff().featurize(ctoc_feats[0])
ofm_feats = OrbitalFieldMatrix().featurize(material[1])

bandgap_feats = []
for i in ep_feats:
    bandgap_feats.append(i)
for i in en_feats:
    bandgap_feats.append(i)
for i in ofm_feats:
    bandgap_feats.append(i)

ep_labels = ep_feat.feature_labels()
en_labels = ElectronegativityDiff().feature_labels()
ofm_labels = OrbitalFieldMatrix().feature_labels()

bandgap_labels = []
for i in ep_labels:
    bandgap_labels.append(i)
for i in en_labels:
    bandgap_labels.append(i)
for i in ofm_labels:
    bandgap_labels.append(i)

bandgap_feats_df = pd.DataFrame(bandgap_feats).T
bandgap_feats_df.columns = bandgap_labels

print(f"Band Gap: {bandgap_regressor.predict(bandgap_feats_df)[0]}")