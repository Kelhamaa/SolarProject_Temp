---
sidebar_position: 4
---

# Learn About Previous Related Literature

## 4. Exploring optical properties of solar cells by programming and modeling

### Key Findings
- The research explores the optical properties of solar cells, focusing on **reducing reflected light to increase efficiency**.
- The study shows that the **absorption** and **reflection factors** of a solar cell coated with an **anti-reflective layer of SiO2** depend on the **thickness** of the layer and the **wavelength of light**.
- By using the **transfer matrix method**, the authors were able to **determine the optical properties of silicon-based solar cells with different coatings**, such as SiO2 and perovskite Cs17Br174.
### Methodologies
- The research employs the **transfer matrix method** to calculate the **absorption and reflection coefficients** of solar cells with anti-reflective coatings.
- **Programming and modeling techniques** were utilized to analyze the optical properties of solar cells at different thicknesses of SiO2 coatings.
- The study also visualized and graphed the results obtained through Svisual to provide a comprehensive analysis of the defined 
### Noteable Insights
- The **refractive index of silicon and air** plays a crucial role in the efficiency of solar cells, with the **refractive index of silicon** ranging from **3-4** depending on the wavelength of light.
- Covering the surface of a solar cell with a **100 nm thick SiO2 layer** is recommended to **improve optical properties and increase efficiency**.
- The research suggests that by **enhancing the optical properties** of solar cells, it is possible to **achieve economic success** by reducing costs and increasing efficiency.

Access the full PDF [here](https://gjeta.com/content/exploring-optical-properties-solar-cells-programming-and-modeling)
