---
sidebar_position: 3
---

# Learn About Previous Related Literature

## 3. Machine Learning Approach to Delineate the Impact of Material Properties on Solar Cell Device Physics

### Key Findings
- The research focused on understanding the factors influencing solar device efficiency, particularly the **normalized efficiency to power input ratio**.
- The device structure included layers such as an **antireflective coating, glass, FTO electrode, ETL, perovskite layer, HTL, and electrode layer**.
- **Noble metals** like Au, Ag, and Pt were commonly used as electrode materials to **reduce electron-hole recombination**.
- The **perovskite** layer plays a crucial role in **absorbing light** to **create electron-hole pairs** for generating electric current3.
- **TiO2** was utilized as the **ETL**, while **Cu2O** acted as the **HTL** in the investigated solar device structure.
### Methodologies
- **SCAPS** simulation software was employed to study the solar device and investigate the impact of material parameters on efficiency.
- Machine learning algorithms, particularly **random forest models**, were utilized to analyze the dataset and determine the relative importance of input material parameters.
- **Feature Importance and SHAP** analysis were conducted to identify the most influential features affecting the target variable (device efficiency).
### Noteable Insights
- Machine learning, as a subfield of artificial intelligence, has become a vital tool in various STEM disciplines, including material science.
- **Perovskite** materials have shown **promising results for light capture** and are crucial for enhancing solar cell performance.
- The study provided insights into how varying material parameters can impact the efficiency of solar devices, aiding experimentalists in optimizing device performance.

Access the full PDF [here](https://pubs.acs.org/doi/10.1021/acsomega.2c01076)