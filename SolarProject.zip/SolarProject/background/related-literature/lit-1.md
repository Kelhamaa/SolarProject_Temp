---
sidebar_position: 1
---

# Learn About Previous Related Literature

## 1. Accelerated Discovery of Efficient Solar-cell Materials using Quantum and Machine-learning Methods.

### Key Findings
- The research focused on identifying **potential solar cell materials** with high efficiency by combining density functional theory (DFT) high-throughput screening and machine learning techniques¹.
- The study identified **58 potential 2D-bulk solar cell materials** with high potential as thin-film solar-cell materials¹.
- A machine learning **classification model** was trained with the spectroscopy limited maximum efficiency (SLME) data to **predict** whether a material will have an SLME above 10%¹.
### Methodologies
- **Density functional theory (DFT)** high-throughput screening was employed to analyze a large volume of materials data with high accuracy .
- The researchers utilized the **meta-GGA TBmBJ formalism** to obtain frequency-dependent dielectric function data for investigating materials.
- **Effective carrier mas**s and **energy above the convex hull** were used to screen candidate materials for **high-efficiency solar applications**.
- **Machine learning techniques** were applied to classify materials based on SLME data and **accelerate** the **discovery of photovoltaic materials**.
### Noteable Insights
- The study provides a **comprehensive suite of data, tools, and methodologies** to expedite the **discovery of photovoltaic materials**, potentially impacting the next generation of materials design.
- By leveraging **advanced computational methods and machine learning**, the research offers a promising approach to **identifying efficient solar cell materials** from **crystallographic information and chemical constituents**.
- The integration of **DFT calculations, dielectric function data, and machine learning models** showcases a multidisciplinary approach to materials discovery for renewable energy applications. 

Access the full PDF [here](https://pubs.acs.org/doi/abs/10.1021/acs.chemmater.9b02166)