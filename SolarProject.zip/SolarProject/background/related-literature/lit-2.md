---
sidebar_position: 2
---

# Learn About Previous Related Literature

## 2. Toward Predicting Efficiency of Organic Solar Cells via Machine Learning and Improved Descriptors

### Key Findings
- The research focuses on predicting the efficiency of organic solar cells using machine learning models based on relevant **microscopic properties** of donor/acceptor molecules as descriptors2 .
- The study emphasizes the importance of considering **orbitals energetically** close to frontier orbitals of donor molecules in the energy conversion process of organic photovoltaics2.
- The **dataset of 280 experimental systems** is utilized to reveal correlations between **organic molecule properties and device performance**, leading to the **identification of potential new candidates** for OPVs2.
### Methodologies
- **Quantum chemical calculations** were performed using the Gaussian 09 package to optimize ground state geometries of molecules and calculate various descriptors such as **IP(v), λh, and Ebind**.
- Machine learning techniques accessible from **Scikit-Learn** were employed to build models using a set of descriptors as input to predict PCE.
- Advanced methods like artificial **neural networks, random forest, and gradient boosting regression tree** were utilized to develop **predictive models** for PCE.
### Noteable Insights
- The study highlights the need to revisit the **importance of occupied and unoccupied orbitals of organic materials in OPVs**, especially for molecules with **small HOMO-LUMO energy gaps**.
- By leveraging machine learning models, researchers can **quickly screen** and **identify lead candidate materials** for organic solar cells before engaging in laborious synthesis and device fabrication.
- The use of advanced ML techniques like **gradient boosting** has shown promising results in predicting PCE for high-throughput virtual screening of new donor molecules for OPVs.

Access the full PDF [here](https://onlinelibrary.wiley.com/doi/10.1002/aenm.201801032)

