---
sidebar_position: 5
---

# Learn About Previous Related Literature

## 5. The annealing effects of tungsten oxide interlayer based on organic photovoltaic cells

### Key Findings
- The study demonstrated that using a **tungsten oxide interlayer** between **ITO and P3HT:PCBM** in organic photovoltaic cells can significantly **improve** device performance.
- The device with a **40 nm thick WO3 film** annealed at 350°C showed the **highest fill factor** (FF) and **power conversion efficiency (PCE)** among the tested configurations.
- **Annealing the WO3 film** led to **increased hydrophobicity, improved P3HT crystallization, and enhanced hole mobility** in the device.
- The increased work function of the annealed WO3 film **improved hole-collection efficiency by reducing the barrier between P3HT and ITO5**.
### Methodologies
- Surface analysis techniques such as **Atomic Force Microscopy (AFM), X-ray Photoelectron Spectroscopy (XPS), and X-ray Diffraction (XRD)** were used to study the effects of annealing on the WO3 film.
- **Current density-voltage curves and work function variations** were measured to assess hole mobility and interfacial properties.
- **XRD** spectra of P3HT films on WO3 interlayers were analyzed to understand the **structural changes** induced by annealing.
### Noteable Insights
- The **annealing process** of the WO3 film resulted in **improved* device performance** by enhancing the properties of the P3HT layer and reducing interfacial barriers.
- The study highlights the **importance of interlayers** in **organic photovoltaic cells** for **efficient charge transport and collection**.
- The findings suggest that **heat-treated** WO3 films can serve as **effective hole collection** materials in **organic photovoltaic devices**. 

Access the full PDF [here](https://www.sciencedirect.com/science/article/abs/pii/S0927024813003863?via%3Dihub)
