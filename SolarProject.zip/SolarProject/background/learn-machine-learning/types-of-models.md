---
sidebar_position: 1
---

# Learn About Machine Learning

## Types of Machine Learning Models:

### Linear Regression
A supervised learning algorithm used for predicting continuous outcomes. It establishes a linear relationship between the input features and the target variable.
![Linear Regression Image](./machine-learning-img/linregress.jpeg)

### Logistic Regression
Commonly used for binary classification tasks, where the target variable has two classes. It models the probability that a given input belongs to a particular class.
![Logistic Regression Image](./machine-learning-img/logregress.jpeg)

### Decision Trees
They partition the feature space into regions based on the values of input features. They make decisions by recursively splitting the data into subsets, guided by criteria.
![Decision Trees Image](./machine-learning-img/decisiontrees.jpeg)

### Random Forrests
An ensemble learning method that constructs multiple decision trees during training and outputs the mode of the classes (classification) or the mean prediction (regression) of the individual trees.
![Random Forrests Image](./machine-learning-img/randomfor.jpeg)

### Support Vector Machines
A powerful supervised learning algorithm used for classification and regression tasks. It finds the hyperplane that best separates the classes in the feature space, maximizing the margin between the classes.
![SVM Image](./machine-learning-img/svm.jpeg)

### Neural Networks
A class of algorithms inspired by the structure and functioning of the human brain. They consist of interconnected nodes (neurons) organized in layers, each performing specific computations.
![Neural Networks Image](./machine-learning-img/neuralnetwork.jpeg)