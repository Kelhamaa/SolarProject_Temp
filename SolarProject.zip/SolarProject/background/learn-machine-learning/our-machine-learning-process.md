---
sidebar_position: 2
---

# Learn About Machine Learning

## Our Machine Learning Process:

![ML Process Image](./machine-learning-img/MLemploymentprocess.jpeg)