---
sidebar_position: 3
---

# Learn About Machine Learning

### Here's a couple handy Introductory Machine Learning Youtube Videos:

- [Introduction to Machine Learning - Simplilearn](https://www.youtube.com/watch?v=ukzFI9rgwfU)**.

- [All Machine Learning Models Explained in 5 Minutes - Learn with Whiteboard](https://www.youtube.com/watch?v=yN7ypxC7838)**.